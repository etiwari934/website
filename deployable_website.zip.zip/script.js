// Wait until the DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
    // Smooth Scroll for Navigation Links
    const navLinks = document.querySelectorAll("nav ul li a");
    navLinks.forEach(link => {
      link.addEventListener("click", event => {
        event.preventDefault();
        const targetId = link.getAttribute("href").slice(1); // Remove '#' from href
        const targetElement = document.getElementById(targetId);
  
        if (targetElement) {
          window.scrollTo({
            top: targetElement.offsetTop - 60, // Adjust for header height
            behavior: "smooth",
          });
        }
      });
    });
  
    // Simulate Contact Form Submission
    const contactForm = document.querySelector("form");
    if (contactForm) {
      contactForm.addEventListener("submit", event => {
        event.preventDefault(); // Prevent default form submission
        alert("Thank you for your message! I'll get back to you soon.");
        contactForm.reset(); // Reset the form fields
      });
    }
  
    // Mobile Menu Toggle (if you implement a hamburger menu)
    const menuToggle = document.getElementById("menu-toggle"); // Add an ID to your menu toggle button
    const navMenu = document.querySelector("nav ul"); // Adjust selector to your nav menu
  
    if (menuToggle && navMenu) {
      menuToggle.addEventListener("click", () => {
        navMenu.classList.toggle("hidden"); // Toggle Tailwind's `hidden` class
      });
    }
  });
  